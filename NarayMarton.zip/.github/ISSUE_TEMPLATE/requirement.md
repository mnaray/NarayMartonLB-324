---
name: Requirement
about: Submit a new requirement for this project.
title: 'REQUIREMENT: <short description>'
labels: ''
assignees: ''

---

# Description
*Write your description here ...*

## Structure
[target system] [must / can] offer the [target role] the ability to [feature] [*optional* add. Information], only [condition].

## Example Description
Reflect Media player must offer the user the ability to load J3D scene graphs from a wrml-File over the network, only when they are logged in.
